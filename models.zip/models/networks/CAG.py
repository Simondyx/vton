import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.utils.spectral_norm as spectral_norm
import numpy as np
import math
from models.networks.base_network import BaseNetwork


# 这就是IC输入虚线框的模块
class SPADE(nn.Module):
    def __init__(self, norm_nc, label_nc):
        super().__init__()
        
        self.first_norm = nn.BatchNorm2d(norm_nc, affine=False)
        ks = 3  # kernel size of convs inside SPADE
        nhidden = 128
        pw = ks // 2
        self.mlp_shared = nn.Sequential(
            nn.Conv2d(label_nc, nhidden, kernel_size=ks, padding=pw),
            nn.ReLU()
        )
        self.mlp_gamma = nn.Conv2d(nhidden, norm_nc, kernel_size=ks, padding=pw)
        self.mlp_beta = nn.Conv2d(nhidden, norm_nc, kernel_size=ks, padding=pw)

    def forward(self, x, segmap):
        normalized = self.first_norm(x)
        
        if tuple(x.shape[2:]) != tuple(segmap.shape[2:]):
            segmap = F.interpolate(segmap, size=x.size()[2:], mode='nearest')
        
        actv = self.mlp_shared(segmap)
        gamma = self.mlp_gamma(actv)
        beta = self.mlp_beta(actv)
        out = normalized * (1 + gamma) + beta
        return out

    
# 这就是图4(b) ResNet block w/ Context-Aware Normalization (CAN)
class ResnetBlock_with_SPADE(nn.Module):
    def __init__(self, fin, fout):
        super().__init__()
        
        self.learned_shortcut = (fin != fout)
        fmiddle = min(fin, fout)
        sp_norm = spectral_norm
        self.conv_0 = sp_norm(nn.Conv2d(fin, fmiddle, kernel_size=3, padding=1))
        self.conv_1 = sp_norm(nn.Conv2d(fmiddle, fout, kernel_size=3, padding=1))
        if self.learned_shortcut:
            self.conv_s = sp_norm(nn.Conv2d(fin, fout, kernel_size=1, bias=False))

        spade_conditional_input_dims = 10
        
        self.norm_0 = SPADE(fin, spade_conditional_input_dims)
        self.norm_1 = SPADE(fmiddle, spade_conditional_input_dims)
        if self.learned_shortcut:
            self.norm_s = SPADE(fin, spade_conditional_input_dims)
        self.activ = nn.LeakyReLU(0.2, inplace=True)

    def forward(self, x, seg):
        if self.learned_shortcut:
            x_s = self.conv_s(self.norm_s(x, seg))
        else:
            x_s = x

        dx = self.conv_0(self.activ(self.norm_0(x, seg)))
        dx = self.conv_1(self.activ(self.norm_1(dx, seg)))
        out = x_s + dx
        return out



# 这个是用G2的位置的， input通道是39，输出3
class CAGUnetGenerator(BaseNetwork):
    def __init__(self, opt, input_nc, output_nc, occlusion_mask=False):
        super(CAGUnetGenerator, self).__init__()
        self.opt = opt

        nl = nn.InstanceNorm2d

        self.conv1 = nn.Sequential(*[nn.Conv2d(input_nc, 64, kernel_size=3, stride=1, padding=1), nl(64), nn.ReLU(),
                                     nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1), nl(64), nn.ReLU()])
        self.pool1 = nn.MaxPool2d(kernel_size=(2, 2))

        self.conv2 = nn.Sequential(*[nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1), nl(128), nn.ReLU(),
                                     nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1), nl(128), nn.ReLU()])
        self.pool2 = nn.MaxPool2d(kernel_size=(2, 2))

        self.conv3 = nn.Sequential(*[nn.Conv2d(128, 256, kernel_size=3, stride=1, padding=1), nl(256), nn.ReLU(),
                                     nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1), nl(256), nn.ReLU()])
        self.pool3 = nn.MaxPool2d(kernel_size=(2, 2))

        self.conv4 = nn.Sequential(*[nn.Conv2d(256, 512, kernel_size=3, stride=1, padding=1), nl(512), nn.ReLU(),
                                     nn.Conv2d(512, 512, kernel_size=3, stride=1, padding=1), nl(512), nn.ReLU()])
        self.drop4 = nn.Dropout(0.5)
        self.pool4 = nn.MaxPool2d(kernel_size=(2, 2))

        self.conv5 = nn.Sequential(*[nn.Conv2d(512, 1024, kernel_size=3, stride=1, padding=1), nl(1024), nn.ReLU(),
                                     nn.Conv2d(1024, 1024, kernel_size=3, stride=1, padding=1), nl(1024),
                                     nn.ReLU()])
        self.drop5 = nn.Dropout(0.5)


        self.up6 = nn.Sequential(
            *[nn.UpsamplingNearest2d(scale_factor=2), nn.Conv2d(1024, 512, kernel_size=3, stride=1, padding=1),
              nl(512),
              nn.ReLU()])

        # self.conv6 = nn.Sequential(*[nn.Conv2d(1024, 512, kernel_size=3, stride=1, padding=1), nl(512), nn.ReLU(),
        #                              nn.Conv2d(512, 512, kernel_size=3, stride=1, padding=1), nl(512), nn.ReLU()])
        self.conv6 = ResnetBlock_with_SPADE(1024, 512)
                                    
        self.up7 = nn.Sequential(
            *[nn.UpsamplingNearest2d(scale_factor=2), nn.Conv2d(512, 256, kernel_size=3, stride=1, padding=1),
              nl(256),
              nn.ReLU()])
        # self.conv7 = nn.Sequential(*[nn.Conv2d(512, 256, kernel_size=3, stride=1, padding=1), nl(256), nn.ReLU(),
        #                              nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1), nl(256), nn.ReLU()])
        self.conv7 = ResnetBlock_with_SPADE(512, 256)

        self.up8 = nn.Sequential(
            *[nn.UpsamplingNearest2d(scale_factor=2), nn.Conv2d(256, 128, kernel_size=3, stride=1, padding=1),
              nl(128),
              nn.ReLU()])
        self.up8_real = nn.Sequential(
            *[nn.UpsamplingNearest2d(scale_factor=2), nn.Conv2d(256, 128, kernel_size=3, stride=1, padding=1),
              nl(128),
              nn.ReLU()])

        # self.conv8 = nn.Sequential(*[nn.Conv2d(256, 128, kernel_size=3, stride=1, padding=1), nl(128), nn.ReLU(),
        #                              nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1), nl(128), nn.ReLU()])
        self.conv8 = ResnetBlock_with_SPADE(256, 128)
        self.conv8_real = ResnetBlock_with_SPADE(256, 128)

        self.up9 = nn.Sequential(
            *[nn.UpsamplingNearest2d(scale_factor=2), nn.Conv2d(128, 64, kernel_size=3, stride=1, padding=1),
              nl(64),
              nn.ReLU()])
        self.up9_real = nn.Sequential(
            *[nn.UpsamplingNearest2d(scale_factor=2), nn.Conv2d(128, 64, kernel_size=3, stride=1, padding=1),
              nl(64),
              nn.ReLU()])

        # self.conv9 = nn.Sequential(*[nn.Conv2d(128, 64, kernel_size=3, stride=1, padding=1), nl(64), nn.ReLU(),
                                    #  nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1), nl(64), nn.ReLU(),
                                    #  nn.Conv2d(64, output_nc, kernel_size=3, stride=1, padding=1)
                                    #  ])
        self.conv9 = ResnetBlock_with_SPADE(128, output_nc)
        self.conv9_real = ResnetBlock_with_SPADE(128, output_nc)

        self.occlusion_mask = occlusion_mask
        if occlusion_mask:
            self.attn_in = 128
            if opt.use_max_f:
                self.attn_in += 1

            self.predict_occlusion = nn.Sequential(*[nn.Conv2d(self.attn_in, 64, kernel_size=3, stride=1, padding=1), nl(64), nn.ReLU(),
                                     nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1), nl(64), nn.ReLU(),
                                     nn.Conv2d(64, 1, kernel_size=3, stride=1, padding=1)
                                     ])

    def forward(self, input_G, max_f=None, seg=None, image_m=None, cloth=None, ref_cloth=None):
        conv1 = self.conv1(input_G) # torch.Size([1, 64, 256, 256])
        pool1 = self.pool1(conv1)  # torch.Size([1, 64, 128, 128])

        conv2 = self.conv2(pool1)
        pool2 = self.pool2(conv2)

        conv3 = self.conv3(pool2)
        pool3 = self.pool3(conv3)

        conv4 = self.conv4(pool3)
        drop4 = self.drop4(conv4)
        pool4 = self.pool4(drop4)   # torch.Size([1, 512, 16, 16])

        conv5 = self.conv5(pool4)
        drop5 = self.drop5(conv5)   # torch.Size([1, 1026, 16, 16])

        _z = torch.cat([image_m, cloth, ref_cloth], 1)  # 分别是去服装目标图，目标衣服，模特衣服 torch.Size([1, 9, 256, 256])
        scale = 1 / math.pow(2, 3)
        _z = F.interpolate(_z, scale_factor=scale, recompute_scale_factor=False)                    # torch.Size([1, 9, 32, 32])
        _seg = F.interpolate(seg, scale_factor=scale, recompute_scale_factor=False, mode="nearest") # torch.Size([1, 1, 32, 32])
        _cat = torch.cat((_seg, _z), dim=1) # 引入seg信息   torch.Size([1, 10, 32, 32])
        
        up6 = self.up6(drop5)
        conv6 = self.conv6(torch.cat([drop4, up6, _cat], 1), _cat)  # input: [1，1024，32，32] -> output: [1，512，32，32]

        _z = torch.cat([image_m, cloth, ref_cloth], 1)  # 分别是去服装目标图，目标衣服，模特衣服 torch.Size([1, 9, 256, 256])
        scale = 1 / math.pow(2, 2)
        _z = F.interpolate(_z, scale_factor=scale, recompute_scale_factor=False)                    # torch.Size([1, 9, 64, 64])
        _seg = F.interpolate(seg, scale_factor=scale, recompute_scale_factor=False, mode="nearest") # torch.Size([1, 1, 64, 64])
        _cat = torch.cat((_seg, _z), dim=1) # 引入seg信息   torch.Size([1, 10, 64, 64])

        up7 = self.up7(conv6)
        conv7 = self.conv7(torch.cat([conv3, up7, _cat], 1), _cat)  # input: [1，512_128，64，64] -> output: [1，256，64，64]

        _z = torch.cat([image_m, cloth, ref_cloth], 1)  # 分别是去服装目标图，目标衣服，模特衣服 torch.Size([1, 9, 256, 256])
        scale = 1 / math.pow(2, 1)
        _z = F.interpolate(_z, scale_factor=scale, recompute_scale_factor=False)                    # torch.Size([1, 9, 128, 128])
        _seg = F.interpolate(seg, scale_factor=scale, recompute_scale_factor=False, mode="nearest") # torch.Size([1, 1, 128, 128])
        _cat = torch.cat((_seg, _z), dim=1) # 引入seg信息   torch.Size([1, 10, 128, 128])

        up8 = self.up8(conv7)
        conv8 = self.conv8(torch.cat([conv2, up8], 1), _cat)  # input: [1，256，128，128] -> output: [1，128，128，128]

        _z = torch.cat([image_m, cloth, ref_cloth], 1)  # 分别是去服装目标图，目标衣服，模特衣服 torch.Size([1, 9, 256, 256])
        _cat = torch.cat((_seg, _z), dim=1) # 引入seg信息   torch.Size([1, 10, 256, 256])

        up9 = self.up9(conv8)                                 # [1，64，256，256]
        conv9 = self.conv9(torch.cat([conv1, up9], 1), _cat)  # input: [1，128，256，256] -> output: [1，3，256，256] 

        # real
        _z = torch.cat([image_m, cloth, ref_cloth], 1)  # 分别是去服装目标图，目标衣服，模特衣服 torch.Size([1, 9, 256, 256])
        scale = 1 / math.pow(2, 1)
        _z = F.interpolate(_z, scale_factor=scale, recompute_scale_factor=False)                    # torch.Size([1, 9, 128, 128])
        _seg = F.interpolate(seg, scale_factor=scale, recompute_scale_factor=False, mode="nearest") # torch.Size([1, 1, 128, 128])
        _cat = torch.cat((_seg, _z), dim=1) # 引入seg信息   torch.Size([1, 10, 128, 128])

        up8 = self.up8_real(conv7)
        conv8 = self.conv8_real(torch.cat([conv2, up8], 1), _cat)  # input: [1，256，128，128] -> output: [1，128，128，128]

        _z = torch.cat([image_m, cloth, ref_cloth], 1)  # 分别是去服装目标图，目标衣服，模特衣服 torch.Size([1, 9, 256, 256])
        _cat = torch.cat((_seg, _z), dim=1) # 引入seg信息   torch.Size([1, 10, 256, 256])

        up9_real = self.up9_real(conv8)                                 # [1，64，256，256]
        conv9_real = self.conv9_real(torch.cat([conv1, up9_real], 1), _cat)  # input: [1，128，256，256] -> output: [1，3，256，256] 

        if self.occlusion_mask:
            if not self.opt.use_max_f:
                occlusion_mask = self.predict_occlusion(torch.cat([conv1, up9], 1))
            else:
                occlusion_mask = self.predict_occlusion(torch.cat([max_f, conv1, up9], 1))
            return conv9, occlusion_mask, conv9_real
        else:
            return conv9, conv9_real

